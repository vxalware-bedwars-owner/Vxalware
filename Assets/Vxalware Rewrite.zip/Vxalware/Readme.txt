Dear Vxalware user,

If you are a mobile player, I am sorry to say but there is no config provided for mobile users as the updates on the mobile version of Vxalware has been postponed. Thus, mobile configs have also been postponed. We regret any inconvenience caused. Thank you for understanding the matter on this subject.

Sincerely,
The Vxalware Team