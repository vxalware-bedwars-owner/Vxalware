Dear User,

Hello. Quick message: The configs for the mobile version of the script is currently disabled. Please check in again about 4 years later or so :). Yeah until then use a PC as I am not able to create a config for mobile. Thanks your your understanding. Oh and also the new vape folder is the one for the PC config. Just copy and paste it into your executor’s workspace folder. (Good luck if you don’t have a workspace folder) So yeah… Thnks

Best Regards,
The Vxalware Team